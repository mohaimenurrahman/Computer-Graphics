#include <windows.h>
#include <GL/glut.h>
#include<math.h>
#include <iostream>
# define PI 3.14159265358979323846
using namespace std;
GLfloat x;
GLfloat y;

void display() {
    glClear(GL_COLOR_BUFFER_BIT);

    glScalef(1.6,1.6,0);
    glTranslatef(0.0,-0.3,0);
    glBegin(GL_LINE_LOOP);
        glVertex3f(0,0,0);
        glVertex3f(-.2,.16,0);
        glVertex3f(-.16,.15,0);
        glVertex3f(-.19,.25,0);
        glVertex3f(-.1,.25,0);
        glVertex3f(-.17,.35,0);
        glVertex3f(-.24,.37,0);
        glVertex3f(-.27,.45,0);
        glVertex3f(-.12,.45,0);
        glVertex3f(-.2,.65,0);
        glVertex3f(.2,.65,0);
        glVertex3f(.12,.45,0);
        glVertex3f(.27,.45,0);
        glVertex3f(.24,.37,0);
        glVertex3f(.17,.37,0);
        glVertex3f(.1,.25,0);
        glVertex3f(.19,.25,0);
        glVertex3f(.16,.15,0);
        glVertex3f(.2,.16,0);
    glEnd();
    glLoadIdentity();
    glScalef(.4,.4,0);
    glTranslatef(2.0,1.7,0);

    glBegin(GL_LINE_LOOP);
        glVertex3f(0,0,0);
        glVertex3f(-.2,.16,0);
        glVertex3f(-.16,.15,0);
        glVertex3f(-.19,.25,0);
        glVertex3f(-.1,.25,0);
        glVertex3f(-.17,.35,0);
        glVertex3f(-.24,.37,0);
        glVertex3f(-.27,.45,0);
        glVertex3f(-.12,.45,0);
        glVertex3f(-.2,.65,0);
        glVertex3f(.2,.65,0);
        glVertex3f(.12,.45,0);
        glVertex3f(.27,.45,0);
        glVertex3f(.24,.37,0);
        glVertex3f(.17,.37,0);
        glVertex3f(.1,.25,0);
        glVertex3f(.19,.25,0);
        glVertex3f(.16,.15,0);
        glVertex3f(.2,.16,0);
    glEnd();
    glLoadIdentity();
    glScalef(.4,.4,0);
    glTranslatef(-2.0,1.7 ,0);

    glBegin(GL_LINE_LOOP);
        glVertex3f(0,0,0);
        glVertex3f(-.2,.16,0);
        glVertex3f(-.16,.15,0);
        glVertex3f(-.19,.25,0);
        glVertex3f(-.1,.25,0);
        glVertex3f(-.17,.35,0);
        glVertex3f(-.24,.37,0);
        glVertex3f(-.27,.45,0);
        glVertex3f(-.12,.45,0);
        glVertex3f(-.2,.65,0);
        glVertex3f(.2,.65,0);
        glVertex3f(.12,.45,0);
        glVertex3f(.27,.45,0);
        glVertex3f(.24,.37,0);
        glVertex3f(.17,.37,0);
        glVertex3f(.1,.25,0);
        glVertex3f(.19,.25,0);
        glVertex3f(.16,.15,0);
        glVertex3f(.2,.16,0);
    glEnd();
    glLoadIdentity();
    glScalef(.4,.4,0);
    glTranslatef(-2.0,-2.3,0);
    glBegin(GL_LINE_LOOP);
        glVertex3f(0,0,0);
        glVertex3f(-.2,.16,0);
        glVertex3f(-.16,.15,0);
        glVertex3f(-.19,.25,0);
        glVertex3f(-.1,.25,0);
        glVertex3f(-.17,.35,0);
        glVertex3f(-.24,.37,0);
        glVertex3f(-.27,.45,0);
        glVertex3f(-.12,.45,0);
        glVertex3f(-.2,.65,0);
        glVertex3f(.2,.65,0);
        glVertex3f(.12,.45,0);
        glVertex3f(.27,.45,0);
        glVertex3f(.24,.37,0);
        glVertex3f(.17,.37,0);
        glVertex3f(.1,.25,0);
        glVertex3f(.19,.25,0);
        glVertex3f(.16,.15,0);
        glVertex3f(.2,.16,0);
    glEnd();
    glLoadIdentity();
    glScalef(.4,.4,0);
    glTranslatef(2.0,-2.3,0);
    glBegin(GL_LINE_LOOP);
        glVertex3f(0,0,0);
        glVertex3f(-.2,.16,0);
        glVertex3f(-.16,.15,0);
        glVertex3f(-.19,.25,0);
        glVertex3f(-.1,.25,0);
        glVertex3f(-.17,.35,0);
        glVertex3f(-.24,.37,0);
        glVertex3f(-.27,.45,0);
        glVertex3f(-.12,.45,0);
        glVertex3f(-.2,.65,0);
        glVertex3f(.2,.65,0);
        glVertex3f(.12,.45,0);
        glVertex3f(.27,.45,0);
        glVertex3f(.24,.37,0);
        glVertex3f(.17,.37,0);
        glVertex3f(.1,.25,0);
        glVertex3f(.19,.25,0);
        glVertex3f(.16,.15,0);
        glVertex3f(.2,.16,0);
    glEnd();
    glLoadIdentity();
    glFlush();
}


int main(int argc, char** argv) {
  glutInit(&argc, argv);
  glutCreateWindow("final-1st");
  glutInitWindowSize(320, 320);
  glutDisplayFunc(display);
  glutMainLoop();
  return 0;
}

#include <windows.h> // for MS Windows

#include <GL/glut.h> // GLUT, include glu.h and gl.h

/* Initialize OpenGL Graphics */

void init (void)
{

     glClearColor (9.0,9.0,9.0,0.0);
     glShadeModel(GL_FLAT);

}

/* Handler for window-repaint event. Call back when the window first appears and

whenever the window needs to be re-painted. */

void display(void)
{

    glClear(GL_COLOR_BUFFER_BIT);
    glColor3f(0.0,0.0,1.0);
    glutWireSphere(2.0,22,16);
    glutSwapBuffers();

glEnd();
glBegin(GL_QUADS); // Each set of 4 vertices form a quad

glColor3f(0.0f, 0.0f, 0.0f); // Red

glVertex2f(-0.4f, -0.2f); // x, y

glVertex2f(0.2f, -0.2f);

glVertex2f(0.2f, 0.0f); // x, y

glVertex2f(-0.4f, 0.0f);

glEnd();



glFlush();




}

void reshape(int w,int h)
{

    glMatrixMode(GL_PROJECTION);
    gluPerspective(70.0,w/(GLfloat)h,3.0,90.0);
    glMatrixMode(GL_MODELVIEW);
    gluLookAt(2.0,4.0,0,0.1,0.0,0.0,0.0,0.0,1.0);

}


/* Main function: GLUT runs as a console application starting at main() */

int main(int argc,char** argv)
{

    glutInit(&argc,argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
    glutInitWindowSize(700,600);
    glutInitWindowPosition(0,275);
    glutCreateWindow("Cbuilding");
    init();
    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutMainLoop();
    return 0;

}


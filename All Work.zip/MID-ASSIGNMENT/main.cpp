#include<windows.h>
#include<GL/glut.h>
#include<math.h>
#define PI 3.1416

void display(){

glClearColor(0.0f,0.0f,0.0f,1.0f);
glClear(GL_COLOR_BUFFER_BIT);

 glBegin(GL_QUADS);

	glColor3f(0.88,0.88,0.88);
	glVertex2f(-0.57,-0.40);
	glVertex2f(-0.57,-0.70);
	glVertex2f(0.57,-0.70);
	glVertex2f(0.57,-0.40);
	glEnd();

 int i;

	GLfloat x=0.0f; GLfloat y=0.1f; GLfloat radius =.8f;
	int triangleAmount = 40;
	GLfloat twicePi = 2.0f * PI;
	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y);
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount)));
		}
	glEnd();

	//door
    glBegin(GL_QUADS);
	glColor3f(0.5,0.7,1.0);
	glVertex2f(-0.17,-0.70);
	glVertex2f(0.17,-0.70);
	glVertex2f(0.17,-0.50);
	glVertex2f(-0.17,-0.50);
	glEnd();

    //DOORLINE
    glBegin(GL_LINES);
	glColor3f(0.0,0.0,1.0);
	glVertex2f(0.0,-0.50);
	glVertex2f(0.0,-0.70);
	glEnd();

	 //GLASS

     //last
	glBegin(GL_QUADS);
	glColor3f(0.5,0.7,1.0);
	glVertex2f(-0.70,-0.30);
	glVertex2f(0.70,-0.30);
	glVertex2f(0.78,-0.10);
	glVertex2f(-0.78,-0.10);
	glEnd();

	//first

	glBegin(GL_QUADS);
	glColor3f(0.5,0.7,1.0);
	glVertex2f(-0.54,0.70);
	glVertex2f(0.54,0.70);
	glVertex2f(0.70,0.50);
	glVertex2f(-0.70,0.50);
	glEnd();

	//middle
	glBegin(GL_QUADS);

	glColor3f(0.5,0.7,1.0);
	glVertex2f(-0.80,0.10);
	glVertex2f(0.80,0.10);
	glVertex2f(0.78,0.30);
	glVertex2f(-0.78,0.30);
	glEnd();

     //top red
	glLineWidth(1);
    glBegin(GL_LINES);
	glColor3f(0.9,0.0,0.0);
	glVertex2f(-0.3,0.84);
	glVertex2f(-0.3,0.99);
	glEnd();

    //middle
	glLineWidth(1);
    glBegin(GL_LINES);
	glColor3f(0.0,0.3,0.0);
	glVertex2f(0.0,-0.50);
	glVertex2f(0.0,0.90);
	glEnd();


	glLineWidth(1);
    glBegin(GL_LINES);
	glColor3f(0.0,0.3,0.0);
	glVertex2f(0.78,-0.1);
	glVertex2f(-0.78,-0.1);
	glEnd();

	glLineWidth(1);
    glBegin(GL_LINES);
	glColor3f(0.0,0.3,0.0);
	glVertex2f(0.70,-0.3);
	glVertex2f(-0.70,-0.3);
	glEnd();

	glLineWidth(1);
    glBegin(GL_LINES);
	glColor3f(0.0,0.3,0.0);
	glVertex2f(0.70,-0.3);
	glVertex2f(-0.70,-0.3);
	glEnd();

	glLineWidth(1);
    glBegin(GL_LINES);
	glColor3f(0.0,0.3,0.0);
	glVertex2f(0.58,-0.45);
	glVertex2f(-0.58,-0.45);
	glEnd();

	glLineWidth(1);
    glBegin(GL_LINES);
	glColor3f(0.0,0.3,0.0);
	glVertex2f(0.79,0.1);
	glVertex2f(-0.79,0.1);
	glEnd();

	glLineWidth(1);
    glBegin(GL_LINES);
	glColor3f(0.0,0.3,0.0);
	glVertex2f(0.78,0.3);
	glVertex2f(-0.78,0.3);
	glEnd();

    //first
	glLineWidth(1);
    glBegin(GL_LINES);
	glColor3f(0.0,0.3,0.0);
	glVertex2f(0.53,0.7);
	glVertex2f(-0.53,0.7);
	glEnd();

	glLineWidth(1);
    glBegin(GL_LINES);
	glColor3f(0.0,0.3,0.0);
	glVertex2f(0.68,0.5);
	glVertex2f(-0.68,0.5);
	glEnd();


	glLineWidth(1);
    glBegin(GL_LINES);
	glColor3f(0.0,0.3,0.0);
	glVertex2f(0.27,-0.70);
	glVertex2f(0.27,0.84);
	glEnd();

	glLineWidth(1);
    glBegin(GL_LINES);
	glColor3f(0.0,0.3,0.0);
	glVertex2f(0.55,-0.45);
	glVertex2f(0.55,0.70);
	glEnd();

	glLineWidth(1);
    glBegin(GL_LINES);
	glColor3f(0.0,0.3,0.0);
	glVertex2f(-0.29,-0.70);
	glVertex2f(-0.29,0.84);
	glEnd();

	glLineWidth(1);
    glBegin(GL_LINES);
	glColor3f(0.0,0.3,0.0);
	glVertex2f(-0.55,-0.43);
	glVertex2f(-0.55,0.68);
	glEnd();

 glFlush();
}

int main(int argc, char** argv) {
	glutInit(&argc, argv);
	glutCreateWindow("C-BUILDING");
	glutInitWindowSize(320, 320);
	glutDisplayFunc(display);
	glutMainLoop();
	return 0;
}

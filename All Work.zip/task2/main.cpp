#include <windows.h>
#include <GL/glut.h>

void initGL() {
	glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
}

void display() {
	glClear(GL_COLOR_BUFFER_BIT);
    glLineWidth(3);
	glBegin(GL_LINES);
	glColor3f(0.0f, 0.0f, 0.0f);
	glVertex2f(0.0f, 0.9f);
	glVertex2f(-0.13f, 0.5f);
	glEnd();
	glPointSize(8.0);
	glBegin(GL_POINTS);
	glColor3f(0.0f, 0.0f, 0.0f);
	glVertex2f(0.0f, 0.9f);
    glEnd();
    glPointSize(8.0);
	glBegin(GL_POINTS);
	glColor3f(0.0f, 0.0f, 0.0f);
	glVertex2f(-0.13f, 0.5f);
    glEnd();
    glBegin(GL_LINES);
	glColor3f(0.0f, 0.0f, 0.0f);
	glVertex2f(0.0f, 0.9f);
	glVertex2f(0.13f, 0.5f);
	glEnd();
    glPointSize(8.0);
	glBegin(GL_POINTS);
	glColor3f(0.0f, 0.0f, 0.0f);
	glVertex2f(0.13f, 0.5f);
    glEnd();

    glBegin(GL_LINES);
	glColor3f(0.0f, 0.0f, 0.0f);
	glVertex2f(0.5f, 0.5f);
	glVertex2f(-0.5f, 0.5f);
	glEnd();
	glPointSize(8.0);
	glBegin(GL_POINTS);
	glColor3f(0.0f, 0.0f, 0.0f);
	glVertex2f(0.5f, 0.5f);
    glEnd();
    glPointSize(8.0);
	glBegin(GL_POINTS);
	glColor3f(0.0f, 0.0f, 0.0f);
	glVertex2f(-0.5f, 0.5f);
    glEnd();

    glBegin(GL_LINES);
	glColor3f(0.0f, 0.0f, 0.0f);
	glVertex2f(0.35f, -0.2f);
	glVertex2f(-0.5f, 0.5f);
	glEnd();
	glPointSize(8.0);
	glBegin(GL_POINTS);
	glColor3f(0.0f, 0.0f, 0.0f);
	glVertex2f(0.35f, -0.2);
    glEnd();

    glBegin(GL_LINES);
	glColor3f(0.0f, 0.0f, 0.0f);
	glVertex2f(-0.35f, -0.2f);
	glVertex2f(0.5f, 0.5f);
	glEnd();
	glPointSize(8.0);
	glBegin(GL_POINTS);
	glColor3f(0.0f, 0.0f, 0.0f);
	glVertex2f(-0.35f, -0.2f);
    glEnd();

    glBegin(GL_LINES);
	glColor3f(0.0f, 0.0f, 0.0f);
	glVertex2f(-0.35f, -0.2f);
	glVertex2f(-0.13f, 0.5f);
	glEnd();

	glBegin(GL_LINES);
	glColor3f(0.0f, 0.0f, 0.0f);
	glVertex2f(0.35f, -0.2f);
	glVertex2f(0.13f, 0.5f);
	glEnd();

	glFlush();
}
int main(int argc, char** argv) {
	glutInit(&argc, argv);
	glutCreateWindow("Task 2");
	glutInitWindowSize(640, 640);
	glutDisplayFunc(display);
	initGL();
	glutMainLoop();
	return 0;
}

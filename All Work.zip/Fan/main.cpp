#include <windows.h>
#include <GL/glut.h>

GLfloat i = 0.0f;


void Idle()
{
    glutPostRedisplay();//// marks the current window as needing to be redisplayed
}
void shape(){
     glBegin(GL_LINE_LOOP);
        glVertex3f(0,0,0);
        glVertex3f(-.2,.16,0);
        glVertex3f(-.16,.15,0);
        glVertex3f(-.19,.25,0);
        glVertex3f(-.1,.25,0);
        glVertex3f(-.17,.35,0);
        glVertex3f(-.24,.37,0);
        glVertex3f(-.27,.45,0);
        glVertex3f(-.12,.45,0);
        glVertex3f(-.2,.65,0);
        glVertex3f(.2,.65,0);
        glVertex3f(.12,.45,0);
        glVertex3f(.27,.45,0);
        glVertex3f(.24,.37,0);
        glVertex3f(.17,.37,0);
        glVertex3f(.1,.25,0);
        glVertex3f(.19,.25,0);
        glVertex3f(.16,.15,0);
        glVertex3f(.2,.16,0);


}
void display()
{
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f); // Black and opaque
    glClear(GL_COLOR_BUFFER_BIT);
     glEnd();



    glPushMatrix();
    glRotatef(0,0,0.0,0.1);
    shape();
    glEnd();
    glPopMatrix;

    glPushMatrix();
    glRotatef(90,0,0.0,0.1);
    shape();
    glEnd();
    glPopMatrix();

   glPushMatrix();
    glRotatef(180,0,0.0,0.1);
    shape();
    glEnd();
    glPopMatrix();


 glPushMatrix();
    glRotatef(270,0,.0,0.1);
    shape();
    glEnd();
    glPopMatrix();

    i+=0.2f;

    glFlush();
}

int main(int argc, char** argv)
{
    glutInit(&argc, argv);          // Initialize GLUT
    glutInitWindowSize(500, 500);
    glutCreateWindow("Rotation");
    glutDisplayFunc(display);//

    glutIdleFunc(Idle);
    glutMainLoop();
    return 0;
}

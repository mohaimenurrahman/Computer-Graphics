#include <windows.h>
#include <stdio.h>
#include <math.h>
#include <iostream>
#include <vector>
#include <GL/glut.h>
using namespace std;

int pntX1, pntY1,edges;
vector<int> pntX;
vector<int> pntY;
char reflectionAxis;

void drawPolygon()
{
	glBegin(GL_POLYGON);
	glColor3f(1.0, 0.0, 0.0);
	for (int i = 0; i < edges; i++)
	{
		glVertex2i(pntX[i], pntY[i]);
	}
	glEnd();
}

void drawPolygonMirrorReflection(char reflectionAxis)
{
	glBegin(GL_POLYGON);
	glColor3f(0.0, 0.0, 1.0);

	if (reflectionAxis == 'x' || reflectionAxis == 'X')
	{
		for (int i = 0; i < edges; i++)
		{
			glVertex2i(round(pntX[i]), round(pntY[i] * -1));

		}
	}
	else if (reflectionAxis == 'y' || reflectionAxis == 'Y')
	{
		for (int i = 0; i < edges; i++)
		{
			glVertex2i(round(pntX[i] * -1), round(pntY[i]));
		}
	}
	glEnd();
}

void myInit(void)
{
	glClearColor(1.0, 1.0, 1.0, 0.0);
	glColor3f(0.0f, 0.0f, 0.0f);
	glPointSize(8.0);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(-640.0, 640.0, -480.0, 480.0);
}


void myDisplay(void)
{
	glClear(GL_COLOR_BUFFER_BIT);
	glColor3f(0.0, 0.0, 0.0);

		drawPolygon();
		drawPolygonMirrorReflection(reflectionAxis);
	glFlush();
}



GLfloat i = 0.0f;
void Idle()
{
    glutPostRedisplay();//// marks the current window as needing to be redisplayed
}
void RotateDisplay()
{
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f); // Black and opaque
    glClear(GL_COLOR_BUFFER_BIT);



    glPushMatrix();
    glRotatef(i,0,0.0,0.1);

    glBegin(GL_QUADS);

    glColor3f(1.0f, 0.0f, 0.0f);
    glVertex2f(0.0f, 0.0f);
    glVertex2f( 0.5f, 0.0f);
    glVertex2f( 0.5f, 0.4f);
    glVertex2f( 0.0f, 0.4f);
    glEnd();

    glPopMatrix();


    i+=0.2f;

    glFlush();
}

char  shearingAxis;
int shearingX, shearingY;

void drawPolygons()
{
	glBegin(GL_POLYGON);
	glColor3f(1.0, 0.0, 0.0);
	for (int i = 0; i < edges; i++)
	{
		glVertex2i(pntX[i], pntY[i]);
	}
	glEnd();
}
void drawPolygonShearing()
{
	glBegin(GL_POLYGON);
	glColor3f(0.0, 0.0, 1.5);

	if (shearingAxis == 'x' || shearingAxis == 'X')
	{
		glVertex2i(pntX[0], pntY[0]);

		glVertex2i(pntX[1] + shearingX, pntY[1]);
		glVertex2i(pntX[2] + shearingX, pntY[2]);

		glVertex2i(pntX[3], pntY[3]);
	}
	else if (shearingAxis == 'y' || shearingAxis == 'Y')
	{
		glVertex2i(pntX[0], pntY[0]);
		glVertex2i(pntX[1], pntY[1]);

		glVertex2i(pntX[2], pntY[2] + shearingY);
		glVertex2i(pntX[3], pntY[3] + shearingY);
	}
	glEnd();
}

void ShearingInit(void)
{
	glClearColor(1.0, 1.0, 1.0, 0.0);
	glColor3f(0.0f, 0.0f, 0.0f);
	glPointSize(4.0);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(-640.0, 640.0, -480.0, 480.0);
}


void ShearingDisplay(void)
{
	glClear(GL_COLOR_BUFFER_BIT);
	glColor3f(0.0, 0.0, 0.0);

		drawPolygons();
		drawPolygonShearing();


	glFlush();
}

void Sd(){

   glBegin(GL_POLYGON);

        glVertex3f(0,0,0);
        glVertex3f(0.5,0.0,0);
        glVertex3f(0.50,0.5,0);
        glVertex3f(0.0,.5,0);
        glEnd();
       glLoadIdentity();
}
void ScaleDisplay() {
    glClearColor(1.0,1.0,1.0,1.0);
    glClear(GL_COLOR_BUFFER_BIT);

    glColor3ub(25,34,34);
    glScalef(1.4,1.4,1.4);
    glTranslatef(0.0,-0.2,0);
    Sd();

    glColor3ub(162,102,110);
    glScalef(-.4,.4,1.4);
    glTranslatef(-.9,0.2,0);
    Sd();


    glFlush();
}
int main(int argc, char** argv)
{
    int option;
	int i=0;
	while(i==0)
    {
       cout<<"Enter option: "<<endl;
       cout<<"1. Mirror Reflection: "<<endl;
       cout<<"2. Rotate : "<<endl;
       cout<<"3. Sharing: "<<endl;
       cout<<"4. Scale & Translate: "<<endl;
       cout<<"5. exit "<<endl<<endl;
       cin>>option;

       switch(option)
       {
            case 1:
            {
                  cout << "Enter no of edges: "; cin >> edges;

	for (int i = 0; i < edges; i++)
	{
		cout << "Enter co-ordinates for vertex " << i + 1 << " : "; cin >> pntX1 >> pntY1;
		pntX.push_back(pntX1);
		pntY.push_back(pntY1);
	}

		cout << "Enter reflection axis ( x or y ): "; cin >> reflectionAxis;

	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
	glutInitWindowSize(640, 480);
	glutInitWindowPosition(100, 150);
	glutCreateWindow("Mirror Reflection");
	glutDisplayFunc(myDisplay);
	myInit();
	glutMainLoop();

            }break;

            case 2:
                {
                        glutInit(&argc, argv);
                        glutInitWindowSize(500, 500);
                        glutCreateWindow("Rotation");
                        glutDisplayFunc(RotateDisplay);//
               glutIdleFunc(Idle);
                        glutMainLoop();
                }break;

            case 3:
                {

	cout << "Shearing" << endl;


    cout << "\n------------\n" << endl;

	cout << "Enter no of edges for a Polygon: "; cin >> edges;

	for (int i = 0; i < edges; i++)
	{
		cout << "Enter co-ordinates for vertex  " << i + 1 << " : "; cin >> pntX1 >> pntY1;
		pntX.push_back(pntX1);
		pntY.push_back(pntY1);
	}
		cout << "Enter reflection axis ( x or y ): "; cin >> shearingAxis;
		if (shearingAxis == 'x' || shearingAxis == 'X')
		{
			cout << "Enter the shearing factor for X: "; cin >> shearingX;
		}
		else
		{
			cout << "Enter the shearing factor for Y: "; cin >> shearingY;
		}


	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
	glutInitWindowSize(640, 480);
	glutInitWindowPosition(100, 150);
	glutCreateWindow("Shearing");
	glutDisplayFunc(ShearingDisplay);
	ShearingInit();
	glutMainLoop();
       }break;


            case 4:
                {
                    glutInit(&argc, argv);
                    glutInitWindowSize(420, 420);
                    glutCreateWindow("Scale & Translate: ");
                    glutDisplayFunc(ScaleDisplay);
                    glutMainLoop();


                }

       }

	}






}
